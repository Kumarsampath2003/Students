﻿using System.Net;
using System.Net.Mail;

namespace WebApplication1.Utilities
{
    public static class EmailFunctions
    {

        public static int SendEmail(string ToAddress, string Password, bool IsRegistation)  //method signature
        {
            int otp = 0;
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                SmtpClient smtpClient = new SmtpClient();
                System.Net.NetworkCredential credentials = new System.Net.
                    NetworkCredential("hr@yesalgo.in", "9880009389");
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = credentials;
                smtpClient.Port = 587;
                smtpClient.EnableSsl = false;
                smtpClient.Host = "smtpout.secureserver.net";
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("hr@yesalgo.in");
                mail.To.Add(ToAddress);
                mail.IsBodyHtml = true;
                var random = new Random();
                otp = random.Next(100000, 500000);
                string mailBody = "<span>Welcome to Yesalgo </span>";

                if (IsRegistation == true)
                {
                    mail.Subject = "Registration is success";
                    mailBody += "Your registration OTP code is : " + otp;
                }
                else
                {
                    mail.Subject = "Your login otp";
                    mailBody += "Your OTP is : " + otp;
                }

                mail.Body = mailBody;
                smtpClient.Send(mail);
            }

            catch (SmtpException ex)
            {
                throw new ApplicationException
                  ("SmtpException has occured: " + ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return otp;
        }


    }
}
