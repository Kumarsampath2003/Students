﻿
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class RegistrationDetails
    {
        [Key]
        public int sno {  get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long MobileNumber { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string MobileOtp { get; set; }
        public string EmailOtp { get; set; }

        

    }
}
