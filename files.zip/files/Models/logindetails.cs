﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class logindetails
    {

        [Key]
        public int id { get; set; }
        [Required]
        [MaxLength(50)]
        public string UserName { get; set; }
        [Required]
        [MaxLength(50)]
        public string Password { get; set; }
        public bool IsAdmin { get; set; }
    }
}
