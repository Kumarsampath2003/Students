﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public partial class UserDbContext:DbContext
    {
        public UserDbContext(DbContextOptions
       <UserDbContext> options)
           : base(options) { }
        public virtual DbSet<logindetails> Logindetails { get; set; }

        public virtual DbSet<RegistrationDetails> RegistrationDetails { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<logindetails>(entity => {
                entity.HasKey(k => k.id);
            });
            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
