﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class DemoController  : ControllerBase
    {
      private readonly UserDbContext _userDbContext;
        public DemoController(UserDbContext userDbContext)
        {
            _userDbContext = userDbContext;
        }
        [HttpPost(Name = "RegisterUser")]
        public async Task<string> PostRegistrationDetails([FromBody] RegistrationDetails registrationDetails)
        {

            
            var CheckEmail = await _userDbContext.RegistrationDetails.Where(x => x.EmailId == registrationDetails.EmailId).FirstOrDefaultAsync();
            if (CheckEmail != null)
            {
                return "your email exist";
            }
            else
            {
                await _userDbContext.RegistrationDetails.AddAsync(registrationDetails).ConfigureAwait(false);
                var isSuccess = _userDbContext.SaveChanges();
               //email otp not send
                return "Welcome to register page";
            }
        }












    }
}
