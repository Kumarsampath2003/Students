﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserDbContext _context;
        public UserController(UserDbContext userDbContext ) {
            _context = userDbContext;
        }

        [HttpGet(Name = "GetDetails")]
        public IEnumerable<logindetails> GetUserDetails()
        {
            return  _context.Logindetails.ToList();
        }
    }
}
