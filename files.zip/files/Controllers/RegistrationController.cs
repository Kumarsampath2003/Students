﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System.Diagnostics.Eventing.Reader;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using WebApplication1.Models;
using WebApplication1.Utilities;
using static System.Net.WebRequestMethods;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RegistrationController : ControllerBase
    {
        private readonly UserDbContext _userDbContext;
        public RegistrationController(UserDbContext userDbContext)
        {
            _userDbContext = userDbContext;
        }




        [HttpPost(Name = "RegisterUsers")]
        //function declaration     //method name                         //inside the rregistartion details field
        public async Task<string> PostRegistrationDetails([FromBody] RegistrationDetails registrationDetails)
        {

            // Filter where x equal to x such that
            var CheckEmail = await _userDbContext.RegistrationDetails.Where(x => x.EmailId == registrationDetails.EmailId).FirstOrDefaultAsync();
            if (CheckEmail != null)
            {
                return "already exists";
            }
            else
            {
                await _userDbContext.RegistrationDetails.AddAsync(registrationDetails).ConfigureAwait(false);
                var isSuccess = _userDbContext.SaveChanges();
                EmailFunctions.SendEmail(registrationDetails.EmailId, "", true);
                return "Registered successfully";
            }
        }
        [HttpGet(Name = "ValidateUser")]
        public async Task<bool> ValidateUser(string EmailId, string Password)
        {
            var validateUser = await _userDbContext.RegistrationDetails.FirstOrDefaultAsync(x => x.EmailId == EmailId && x.Password == Password).ConfigureAwait(false);
            if (validateUser != null)
            {
                return true;

            }
            else
            {
                return false;
            }



        }
        [HttpGet("{Email}")]
        public async Task<string> ForgotPassword(string Email)
        {
            var ForgotPassword = await _userDbContext.RegistrationDetails.FirstOrDefaultAsync(x => x.EmailId == Email).ConfigureAwait(false);
            if (ForgotPassword != null)
            {
                var otp = EmailFunctions.SendEmail(Email, ForgotPassword.Password, false);
                ForgotPassword.EmailOtp = otp.ToString();
                _userDbContext.SaveChanges();
                return ForgotPassword.Password;
            }
            else
            {
                return "User not found ";
            }

        }
        [HttpGet("{Emailid}/{otp}/{reenterdpassword}")]//attribute routing

        public async Task<string> Reenteredpassword(string Emailid,string otp, string reenterdpassword)
        {
            var reenterpassword = await _userDbContext.RegistrationDetails.FirstOrDefaultAsync(x=>x.EmailId==Emailid&&x.EmailOtp==otp).ConfigureAwait(false);
            if (reenterpassword != null)
            {
                reenterpassword.Password = reenterdpassword;
                _userDbContext.SaveChanges(true);
            }
            return "updated successfully";
        }

            
        [HttpDelete(Name = "Deleteaccount")]

        public async Task<string> Deleteaccount(string username)
        {

            var Deleteaccount = await _userDbContext.RegistrationDetails.FirstOrDefaultAsync(x => x.EmailId == username).ConfigureAwait(false);

            if (Deleteaccount != null)
            {
                _userDbContext.RegistrationDetails.Remove(Deleteaccount);
                await _userDbContext.SaveChangesAsync();
                return "deleted successfully";
            }
            else
            {
                return "account does't exists";
            }
        }
        [HttpPut(Name = "Updateprofile")]
        public async Task<string> profile(string Emailid,long mobileno)
        {
           // SendMessageToWhatsApp("","ssk");
            var Putprofile = await _userDbContext.RegistrationDetails.FirstOrDefaultAsync(x => x.EmailId == Emailid).ConfigureAwait(false);
            if (Putprofile != null)
            { 
                Putprofile.MobileNumber = mobileno;
                await _userDbContext.SaveChangesAsync();
                return "Profile updated";
            }
            else
            {
                return "profile not updated";
            }
        }

        private async Task<ContentResult> SendMessageToWhatsApp(string to, string message)
        {
            dynamic finalResult = null;
            string SendMessagesAPIPath = "https://graph.facebook.com/v20.0/34444353344/messages";

            // Create an instance of the Message body. It is a predefined body
            var messageBody = new
            {
                messaging_product = "whatsapp",
                to = "91" + "7483952406",
                type = "text",
                text = new
                {
                    body = "API messages : " + message
                }
            };


            // Use HttpClient or any other method to send the message via WhatsApp API
            using (var httpClient = new HttpClient())
            {
                var authheader = new AuthenticationHeaderValue("Bearer", "EAAQI9IjUnZB4BOyQuNnlomnppEogZD");
                httpClient.DefaultRequestHeaders.Authorization = authheader;
                var response = await httpClient.PostAsJsonAsync(SendMessagesAPIPath, messageBody);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    finalResult = new ContentResult
                    {
                        Content = result,
                        ContentType = "application/json",
                        StatusCode = (int)response.StatusCode
                    };

                    return finalResult;
                }
            }

            return finalResult;
        }


    }
}
